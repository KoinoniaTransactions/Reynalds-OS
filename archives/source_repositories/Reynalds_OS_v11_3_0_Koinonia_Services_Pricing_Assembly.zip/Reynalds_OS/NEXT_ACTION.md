# NEXT ACTION

## Next sprint

Production Sprint — About Page Assembly.

## First task

Inspect the repository for existing About page content, specs, or components. Determine whether the About page can be assembled from:

- `COMP-HERO-001`
- `COMP-TRUST-001`
- `COMP-CARD-004`
- `COMP-CTA-001`
- `COMP-FOOTER-001`

## Expected output

A real repository release that adds the public About page route and assembly using canonical components and minimum new code.

## Do not do

- Do not start broad platform work.
- Do not overwrite the internal ROS dashboard.
- Do not create duplicate components if existing canonical components can be reused.
- Do not mark a page complete unless actual repository files exist and are released.

## Optional before next sprint

Run local/browser validation for `/koinonia` and `/koinonia/services` if the user wants visual QA before continuing page assembly.
