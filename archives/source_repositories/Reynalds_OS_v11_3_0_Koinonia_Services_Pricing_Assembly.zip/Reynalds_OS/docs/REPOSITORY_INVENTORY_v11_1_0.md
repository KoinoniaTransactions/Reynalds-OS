# Repository Inventory v11.1.0

## Canonical base

`Reynalds_OS_Git_Project_v10_1.zip` was used as the canonical base for this repository-first release.

## Superseded inputs

- `Reynalds_OS_Git_Project_v8_0.zip` is older than v10.1 and is not the active base.
- `ROS_Koinonia_Interactive_App_Shell_v7_2.html` is preserved as a historical prototype, not an active application source.

## Active application source

- `apps/web/` — Next.js application.
- `packages/design-system/` — shared styles and design tokens.
- `apps/web/components/site/` — canonical public website components.

## Continuity source

- `START_HERE.md`
- `CURRENT_STATE.md`
- `PROJECT_MEMORY.md`
- `NEXT_ACTION.md`
- `AI_DEVELOPMENT_CHARTER.md`
