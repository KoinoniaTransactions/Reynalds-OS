# Website Release Readiness Checklist

## Architecture

- Canonical components used.
- No duplicate component implementations.
- Files live in their correct owner folders.

## Visual

- Typography, spacing, cards, buttons, and section rhythm match the design system.

## Responsive

- Desktop, tablet, and mobile layouts verified.
- No overflow.
- Tap targets are usable.

## Squarespace / Public Website Compatibility

- If a section is exported to Squarespace, live rendering must be checked against editor rendering.
- Known whitespace and HTML-block issues must be documented.

## Accessibility

- Semantic headings.
- Sufficient contrast.
- Meaningful link text.
- Keyboard-safe interactive elements.

## SEO

- One clear H1.
- Descriptive page title and meta description.
- Internal links support the customer journey.

## Release decision

A page may be marked Production Released only when actual repository files pass this checklist.
