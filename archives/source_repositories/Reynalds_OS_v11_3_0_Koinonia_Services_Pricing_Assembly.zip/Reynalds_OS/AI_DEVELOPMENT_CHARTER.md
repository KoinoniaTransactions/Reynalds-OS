# AI DEVELOPMENT CHARTER

## Purpose

This charter defines how AI assistants must work on Reynalds OS.

## Before every task

1. Perform OS Verification.
2. Identify the canonical object/file/module.
3. Check for duplicates and older versions.
4. Explain the plan and launch impact.
5. Wait for user approval before implementation.

## During every task

1. Work against actual repository files.
2. Reuse before replacing.
3. Preserve approved work.
4. Archive rather than delete when history matters.
5. Keep Koinonia website launch as the primary objective.

## After every task

1. Update relevant files.
2. Update version/release notes/change log/object registry when appropriate.
3. Update continuity files: `CURRENT_STATE.md`, `PROJECT_MEMORY.md`, and `NEXT_ACTION.md`.
4. Produce a real release ZIP.

## Prohibited behavior

- Do not claim repository changes were made unless files were actually edited.
- Do not create duplicate frameworks when an existing OS object can be extended.
- Do not use chat memory as the source of truth over repository files.


## Session handoff requirement

Before pausing a major session, update or create a session report under `docs/session_reports/`, update `ARCHITECT_HANDOFF.md`, and refresh `CURRENT_STATE.md`, `PROJECT_MEMORY.md`, and `NEXT_ACTION.md`.
