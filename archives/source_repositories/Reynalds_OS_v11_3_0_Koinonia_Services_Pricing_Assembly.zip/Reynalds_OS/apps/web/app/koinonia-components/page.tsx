import { SiteComponentsPreview } from '../../components/site/site-components-preview';

export default function KoinoniaComponentsPage() {
  return <SiteComponentsPreview />;
}
