# Home Page Assembly Audit

## Status

Queued for Production Sprint 002.

## Assembly approach

The Home page should be assembled from canonical components rather than redesigned.

## Expected components

| Section | Component | Action |
|---|---|---|
| Hero | COMP-HERO-001 | Reuse with Home content |
| Trust / Value | COMP-TRUST-001 | Reuse/refine |
| Services Preview | COMP-CARD-004 | Reuse service card variant |
| CTA | COMP-CTA-001 | Reuse |
| Footer | COMP-FOOTER-001 | Reuse |

## Open implementation decision

The current root route is the internal ROS dashboard. Before adding the public Koinonia Home page, decide whether it belongs at `/koinonia`, `/koinonia-home`, or as the root public route.
