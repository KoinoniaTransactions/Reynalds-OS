# Services & Pricing Production Specification v1.0

## Mission

Help Realtors identify Koinonia as a long-term operational partner, not just a transaction coordination vendor.

## Approved section order

1. Hero
2. Trust
3. Services
4. How It Works
5. Support Levels
6. FAQ
7. Final CTA
8. Footer

## Visitor psychology

- Hero: What is Koinonia?
- Trust: Why should I trust them?
- Services: How can they help me?
- How It Works: What happens if I work with them?
- Support Levels: What level fits my business?
- FAQ: Is there any reason not to contact them?
- CTA: How do I get started?

## Key principles

- Lead with support, not price.
- Write from the Realtor's perspective.
- FAQ removes hesitation, not just answers random questions.
- CTA is low-pressure and confident: when you are ready, we are ready.
