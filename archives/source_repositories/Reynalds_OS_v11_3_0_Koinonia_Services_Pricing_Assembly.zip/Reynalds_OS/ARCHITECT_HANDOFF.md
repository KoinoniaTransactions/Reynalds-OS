# Architect Handoff — Reynalds OS / Koinonia Website

## Current Release

v11.3.0

## What This Project Is

Reynalds OS is the operating repository and development system for multiple business/workflow applications. The active project is the Koinonia public website and related Koinonia operating application.

## Source of Truth

The repository is authoritative. Chat history and memory are secondary. If a claim is not reflected in repository files, it is not complete.

## Current Priority

Launch the Koinonia public website.

## Current Development Model

1. Repository-first execution.
2. Component-first website architecture.
3. Launch-first prioritization.
4. Extend before creating.
5. Reuse before refining; refine before replacing; replace before creating new.

## Do Not Break These Rules

- Do not overwrite approved work without explicit approval.
- Do not create duplicate frameworks/components if an existing object can be extended.
- Do not claim repository work was completed unless files were actually changed.
- Do not let Reynalds OS platform ideas delay the Koinonia website launch.
- Do not treat the internal ROS dashboard and the public Koinonia website as the same surface without explicit architectural approval.

## Current Component Architecture

Canonical public website components are under:

`apps/web/components/site/`

Current canonical components:

- `COMP-HERO-001`
- `COMP-TRUST-001`
- `COMP-CARD-004`
- `COMP-CTA-001`
- `COMP-FAQ-001`
- `COMP-FOOTER-001`

## Current Public Website Routes

- `/` — internal Reynalds OS dashboard. Preserve.
- `/koinonia` — public Koinonia Home page assembled in v11.2.0.
- `/koinonia/services` — public Koinonia Services & Pricing page assembled in v11.3.0.
- `/koinonia-components` — public component preview/verification route.

## Last Completed Work

Production Sprint 003 — Services & Pricing Page Assembly.

The Services & Pricing release-readiness sprint found that the actual route was missing, so the route was assembled from canonical components before marking readiness status.

## Next Work

Begin **About Page Assembly**.

First inspect actual files to verify whether any About content already exists:

- `apps/web/app/`
- `apps/web/components/site/`
- `docs/website/`
- relevant BRAIN documentation

Do not rely on prior conversation claims. Assemble from canonical components wherever possible.

## Success Criteria For Next Sprint

A real repository release containing:

- Public About page route/assembly
- Updated continuity files
- Updated release notes/changelog/object registry
- Version bump
- Release ZIP
