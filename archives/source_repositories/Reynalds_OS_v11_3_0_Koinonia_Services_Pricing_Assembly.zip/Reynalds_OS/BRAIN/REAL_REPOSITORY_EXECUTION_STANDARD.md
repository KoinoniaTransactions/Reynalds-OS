# Real Repository Execution Standard

## Rule

No work is complete unless it is reflected in the actual repository files.

## Required evidence

A completed sprint must include one or more of the following actual repository changes:

- Source code update
- Documentation update
- Registry update
- Version update
- Release package

## Forbidden

Conceptual locks, undocumented approvals, or chat-only decisions cannot be treated as complete.

## Future chat handoff

Future chats must start by reading `START_HERE.md` and the continuity files before making recommendations.
