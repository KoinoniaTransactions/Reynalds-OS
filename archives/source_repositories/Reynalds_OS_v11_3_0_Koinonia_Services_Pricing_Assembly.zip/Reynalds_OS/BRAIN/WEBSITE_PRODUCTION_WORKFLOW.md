# Website Production Workflow

## Lifecycle

1. OS Verification
2. Architect Review
3. Approval
4. Repository Implementation
5. QA / Release Readiness
6. OS Synchronization
7. Versioned Release

## Page states

- Draft
- Strategy Locked
- Implementation Locked
- QA Verified
- Production Released

## Launch-first classification

- Required Before Launch
- Version 1.1 Enhancement
- Future Vision

## Component-first rule

Pages are assemblies of canonical components. Components live under `apps/web/components/site/` and are tracked in `BRAIN/COMPONENT_CATALOG.md`.
