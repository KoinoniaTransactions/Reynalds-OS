# Decision Log

## D-001 — Use Shared Object Engine

Decision: Use `RosObject` as the central registry for business records.

Reason: Prevents disconnected module data and supports cross-module intelligence.

## D-002 — Use Timeline Events

Decision: Meaningful changes create timeline events.

Reason: Supports auditability, troubleshooting, and AI grounding.

## D-003 — Use Read-Only Copilot First

Decision: Copilot starts read-only.

Reason: Builds trust before allowing AI actions.

## D-004 — Use Workflow Engine as Long-Term Automation Core

Decision: Future automation should flow through workflow definitions and workflow runs.

Reason: Prevents each module from creating separate automation logic.

## D-005 — Move Away From Incremental Static App Shells

Decision: v7.2 static app shell should be considered superseded by the production Next.js app.

Reason: The project now needs a real running software workflow, not separate static prototype files.

## D-006 — Keep Brain Inside Repository

Decision: Store core architecture and development rules in `BRAIN/`.

Reason: Future development should start from repository truth, not memory.

## D-007 — Repository-First Execution Standard

Decision: Work is not complete unless actual repository files are inspected, modified, documented, and released.

Reason: Prevents conceptual progress from being mistaken for real implementation.

## D-008 — Component-First Website Architecture

Decision: Koinonia website pages are assemblies of canonical components under `apps/web/components/site/`.

Reason: Reduces duplication, improves consistency, and accelerates Home/About/Contact production.


---

## Decision — 2026-07-03 — Repository-First Continuity and Session Handoff

**Decision:** Every major session must end with repository-based continuity documentation when work is paused.

**Reason:** Future chats must be able to resume from the repository without depending on conversational memory.

**Impact:** `START_HERE.md`, `CURRENT_STATE.md`, `PROJECT_MEMORY.md`, `NEXT_ACTION.md`, `ARCHITECT_HANDOFF.md`, and session reports are now part of the project handoff system.

**Status:** Approved and implemented in v11.1.1.
