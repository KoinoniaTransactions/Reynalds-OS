# Reynalds OS Handoff

## Current Version

v11.1.1

## Read First

1. `START_HERE.md`
2. `CURRENT_STATE.md`
3. `PROJECT_MEMORY.md`
4. `NEXT_ACTION.md`
5. `AI_DEVELOPMENT_CHARTER.md`
6. `ARCHITECT_HANDOFF.md`
7. `docs/session_reports/SESSION_REPORT_2026-07-03.md`

## Current Priority

Launch the Koinonia public website.

## Current Sprint

Production Sprint 002 — Home Page Assembly.

## Development Rule

Repository files are authoritative. Do not rely on chat memory over repository state.
