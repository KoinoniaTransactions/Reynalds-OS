# Component Catalog

## Purpose

The Component Catalog is the authoritative index of reusable Koinonia website components inside Reynalds OS.

## Canonical location

`apps/web/components/site/`

## Components

| Component ID | Name | Status | Owner | Used By |
|---|---|---|---|---|
| COMP-HERO-001 | Primary Hero | Canonical | Website System | Home, Services & Pricing, About, Contact |
| COMP-TRUST-001 | Trust Pillar Section | Canonical | Website System | Home, Services & Pricing, About |
| COMP-CARD-004 | MOD-004 Universal Content Card | Canonical | Design System | Home, Services, Support Levels, Features, Process, Team |
| COMP-CTA-001 | Primary CTA Section | Canonical | Website System | All public website pages |
| COMP-FAQ-001 | FAQ / Objection Resolution Section | Canonical | Website System | Services & Pricing, Contact |
| COMP-FOOTER-001 | Koinonia Footer | Canonical | Website System | All public website pages |

## Rule

If a UI pattern appears more than twice, it should become or reuse a canonical component.


## Page Assemblies

| Page ID | Route | Status | Components |
|---|---|---|---|
| PAGE-KOINONIA-HOME | `/koinonia` | Assembled | COMP-HERO-001, COMP-TRUST-001, COMP-CARD-004, COMP-CTA-001, COMP-FOOTER-001 |

## Routing Rule

The internal Reynalds OS dashboard remains at `/`. Public Koinonia website pages should live under public website routes such as `/koinonia`, `/koinonia/services`, `/koinonia/about`, and `/koinonia/contact` unless explicitly changed.
