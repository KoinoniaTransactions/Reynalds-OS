# START HERE — Reynalds OS

## Required boot sequence for every future chat

1. Read `CURRENT_STATE.md`.
2. Read `PROJECT_MEMORY.md`.
3. Read `NEXT_ACTION.md`.
4. Read `AI_DEVELOPMENT_CHARTER.md`.
5. Read `ARCHITECT_HANDOFF.md`.
6. Read the latest file in `docs/session_reports/`.
7. Verify the actual repository files before recommending or claiming work.

## Governing rule

Reynalds OS is the authoritative project memory. Chat history is useful, but it is not the source of truth.

## Current version

v11.3.0

## Current priority

Launch the Koinonia public website using repository-first development.

## Current next action

Begin About Page Assembly using actual repository files and canonical components.
