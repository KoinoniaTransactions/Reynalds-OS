# PROJECT MEMORY

## Active project

Koinonia public website inside Reynalds OS.

## Current objective

Ship a professional public website for Koinonia using reusable components, production QA, and repository-first development.

## Current release

v11.3.0

## Last completed sprint

Production Sprint 003 — Services & Pricing Page Assembly and Release Readiness checkpoint.

## Current sprint

Production Sprint — About Page Assembly.

## Critical working agreements

- Reynalds OS is the source of truth.
- Do not claim a change is complete unless actual repository files were inspected, edited, and released.
- Verify before creating.
- Extend before replacing.
- Reuse before refining; refine before replacing; replace before creating new.
- Explain the next task before implementing and wait for approval.
- Every meaningful approved change updates the OS and creates a release package.
- Launch comes first.
- Documentation is part of the product.

## Website production sequence

1. Home Page Assembly. ✅
2. Services & Pricing Page Assembly. ✅
3. Services & Pricing browser QA. ⏳
4. About Page Assembly. ⏳
5. Contact Page Assembly.
6. Site-wide QA.
7. Launch Candidate.

## Current public website routes

- `/` — internal Reynalds OS dashboard. Preserve.
- `/koinonia` — public Koinonia Home page.
- `/koinonia/services` — public Koinonia Services & Pricing page.
- `/koinonia-components` — canonical component preview route.

## Component-first principle

Pages are assemblies. Components are canonical reusable objects.

## Current canonical website components

- `COMP-HERO-001` Primary Hero
- `COMP-TRUST-001` Trust Pillar Section
- `COMP-CARD-004` MOD-004 Universal Content Card
- `COMP-CTA-001` Primary CTA Section
- `COMP-FAQ-001` FAQ / Objection Resolution Section
- `COMP-FOOTER-001` Koinonia Footer

## Latest assembly decision

Services & Pricing release readiness revealed that the actual route was missing. The correct action was to assemble `/koinonia/services` first, using canonical components, rather than claiming release readiness against documentation only.

## Important handoff note

Read `ARCHITECT_HANDOFF.md`, latest `docs/session_reports/`, `docs/website/HOME_PAGE_ASSEMBLY_v11_2_0.md`, and `docs/website/SERVICES_PRICING_RELEASE_READINESS_v11_3_0.md` before beginning the next sprint.
