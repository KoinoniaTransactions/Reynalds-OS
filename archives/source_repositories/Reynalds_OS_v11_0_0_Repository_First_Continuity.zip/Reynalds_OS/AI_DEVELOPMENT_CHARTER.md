# AI DEVELOPMENT CHARTER — Reynalds OS

## Purpose

This charter governs how an AI assistant or developer should work on Reynalds OS and the Koinonia website.

## Core Rule

Reynalds OS is the source of truth. Do not rely on chat memory as the authoritative project record.

## Required Behavior Before Every Task

1. Verify the OS.
2. Identify the canonical file/object/module.
3. Check whether the work already exists.
4. Prefer extending over creating.
5. Explain the next action before implementation.
6. Wait for approval when working interactively.

## Required Behavior During Work

- Work directly in repository files.
- Reuse before refining.
- Refine before replacing.
- Replace only when necessary.
- Create new only as a last resort.
- Keep launch first.
- Preserve architecture.
- Record why important decisions are made.

## Required Behavior After Work

Every meaningful change must update:

- `VERSION`
- `CURRENT_STATE.md`
- `PROJECT_MEMORY.md`
- `NEXT_ACTION.md`
- `RELEASE_NOTES.md`
- `ROADMAP.md` when relevant
- `05_Change_Log/change_log.csv`
- `object_registry.csv` when objects are added/changed
- relevant `BRAIN/` or `03_Knowledge/` files

## Real Repository Execution Standard

Do not claim that a file, component, page, or OS version was completed unless the actual repository files were modified and a new release package was produced.

## Communication Rule

When the user says `next`, respond with:

1. OS Verification
2. Architect Review
3. Recommendation
4. Implementation Plan
5. Wait for approval unless the user has already clearly approved execution.

## Launch Classification

Classify new ideas as:

- Required before launch
- Version 1.1 enhancement
- Future vision

## Honesty Rule

If something cannot be verified from the repository, say: `I cannot verify this from the repository.`
