# ROS Roadmap

## Current Release

ROS v11.0.0 — Repository-First Continuity and Koinonia Website Production Standard

## Completed

- Production codebase scaffold
- Object API persistence
- Object Explorer UI
- CRM MVP
- Transactions MVP
- Operations Queue MVP
- Finance MVP
- Database dashboard metrics
- Knowledge MVP
- Read-only Copilot MVP
- Notifications MVP
- Automatic notification generation
- Workflow Automation Engine MVP
- Authoritative BRAIN documentation
- Continuity package for chat-to-chat handoff
- Real repository execution standard
- Koinonia website production workflow
- Services & Pricing strategy specification
- Website release readiness checklist

## Immediate Next Work

1. Perform Repository Sprint 1.
2. Establish the canonical public website implementation path.
3. Verify whether Koinonia website pages currently exist as source files.
4. Build or refine the first real public website page.
5. Run release-readiness checklist against actual files.

## Website Launch Sequence

1. Canonical website implementation setup.
2. Home page implementation.
3. Services & Pricing implementation.
4. About page implementation.
5. Contact page implementation.
6. Site-wide QA.
7. Launch candidate.

## Platform Work Deferred Until After Website Launch

- Advanced CRM expansion
- Client portal enhancements
- AI action automation
- Multi-company deployment
- Advanced analytics

## Long-Term Product Work

1. Workflow step execution engine.
2. Workflow run stage advancement.
3. Workflow action registry.
4. Server-side search.
5. Managed authentication.
6. Deployment setup.
