# START HERE — Reynalds OS Continuity Boot Sequence

Version: v11.0.0

This file is the first file to read when continuing Reynalds OS in a new chat or with a new developer.

## Required Reading Order

1. `CURRENT_STATE.md`
2. `PROJECT_MEMORY.md`
3. `AI_DEVELOPMENT_CHARTER.md`
4. `NEXT_ACTION.md`
5. `BRAIN/REAL_REPOSITORY_EXECUTION_STANDARD.md`
6. `03_Knowledge/Website/website_status.md`

## Governing Rule

Reynalds OS is the project source of truth. Chat history is helpful but not authoritative.

Do not claim work is complete unless the actual repository files were inspected, modified, documented, versioned, and released.

## Current Priority

Launch the Koinonia public website while preserving Reynalds OS as the authoritative project repository.

## Immediate Next Action

Follow `NEXT_ACTION.md`.
