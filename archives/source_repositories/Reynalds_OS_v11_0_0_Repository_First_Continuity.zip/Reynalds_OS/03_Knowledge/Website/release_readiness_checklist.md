# Website Release Readiness Checklist

## Status

Active QA checklist for Koinonia website pages.

## Use

Every page must pass this checklist before being marked Production Released.

## Gate 1 — Content QA

- The page answers the correct visitor questions.
- Headline hierarchy is clear.
- Copy is concise.
- CTA is clear.
- No unnecessary sections remain.

## Gate 2 — Component Integrity QA

- Canonical components are reused where possible.
- No duplicate component systems are introduced.
- MOD-004 / Universal Content Card is used for repeated card patterns where applicable.
- Footer/CTA/Hero patterns remain consistent.

## Gate 3 — Visual QA

- Spacing is consistent.
- Typography scale is consistent.
- Cards align cleanly.
- Buttons are consistent.
- Section rhythm feels calm and premium.

## Gate 4 — Responsive QA

- Desktop layout verified.
- Tablet layout verified.
- Mobile layout verified.
- No horizontal overflow.
- Tap targets are large enough.
- Text remains readable.

## Gate 5 — Platform / Squarespace QA

- HTML block behavior verified if using Squarespace.
- Editor and live site checked.
- Whitespace issues checked.
- Footer interaction checked.
- Mobile live rendering checked.

## Gate 6 — Accessibility QA

- Semantic heading order.
- Sufficient color contrast.
- Buttons/links are keyboard usable.
- Images have appropriate alt text.
- Interactive states are visible.

## Gate 7 — SEO QA

- One clear H1.
- Logical H2/H3 structure.
- Meta title drafted.
- Meta description drafted.
- Internal links reviewed.
- Image naming and alt text reviewed.

## Release Decision

Final question: Would we publish this page today if Koinonia were going live tomorrow?

Only a confident yes may be recorded as Production Released.
