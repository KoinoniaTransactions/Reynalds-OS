# Koinonia Website Component Catalog

## Status

Initial catalog. Must be verified against actual repository implementation before certification.

## Component-First Principle

Pages should be assembled from reusable components rather than redesigned section by section.

## Known / Approved Component Patterns

### Hero Component

Used for page introductions.

Configurable fields:

- eyebrow
- headline
- supporting text
- CTA
- optional visual/image

### Trust Block

Used to establish credibility through concise trust pillars.

### MOD-004 / Universal Content Card

Existing component concept from the ROS Component Library.

Recommended variants:

- Service Card
- Support Level Card
- Process Card
- Feature Card
- Team Card
- Testimonial Card

### FAQ Block

Used for objection handling, not general documentation.

### Final CTA

Used to remove friction and invite contact with calm confidence.

### Footer

Canonical site-wide closing component.

## Verification Needed

The component catalog must be mapped to actual source files during the next repository sprint.
