# PROJECT MEMORY — Reynalds OS / Koinonia

## Purpose

This file preserves the project state across chats so the next conversation can resume accurately without rebuilding context from memory.

## Governing Memory Rule

If there is a conflict between chat memory and Reynalds OS, Reynalds OS wins.

## Current Project

Build the Koinonia website inside Reynalds OS and preserve the repository as the single source of truth.

## Current Website Direction

The Koinonia website is being built as a calm, organized, premium-feeling real estate operations support website.

Core brand experience:

- professional
- calm
- organized
- dependable
- relationship-focused
- premium without being flashy

The website should demonstrate what working with Koinonia feels like.

## Approved Public Site Navigation

- Home
- Services & Pricing
- About
- Contact

## Approved Service Categories

- Transaction Management
- Contract Preparation & Writing
- Licensed Showing Coverage
- Business Support

## Approved Website Philosophy

Every section should answer the next question in the visitor's mind.

Customer journey pattern:

1. Hero — What is this?
2. Trust — Why should I believe them?
3. Services — How can they help me?
4. Process — What happens if I work with them?
5. Support Levels — What level of support fits my business?
6. FAQ — Is there any reason not to reach out?
7. CTA — How do I get started?

## Approved Copywriting Principles

- Write from the Realtor's perspective.
- Focus on outcomes before features.
- Partnership before transaction.
- Confidence before urgency.
- Simplicity before detail.
- Avoid pressure-based sales language.

## Approved Development Methodology

Every task must follow:

1. OS Verification
2. Architect Review
3. Recommendation
4. Approval
5. Implementation in real repository files
6. OS synchronization
7. Versioned release package

## Launch Priority

Launch comes first.

Classify work as:

- Required before launch
- Version 1.1 enhancement
- Future vision

Do not let future-platform ideas delay the Koinonia website launch.

## Current Sprint

Repository-first Sprint 0: establish continuity, repository execution standard, website production rules, and next action from the actual v10.1 base.

## Last Completed Repository Work

This v11.0.0 release documents the continuity package and real repository execution standard in the actual repository files.

## Next Action

Use `NEXT_ACTION.md`.
