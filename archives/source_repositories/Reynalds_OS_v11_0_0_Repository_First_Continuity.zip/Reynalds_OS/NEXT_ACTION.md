# NEXT ACTION — Reynalds OS

## Immediate Next Task

Perform a real repository inventory of the Koinonia website assets and determine the canonical implementation path for the public website.

## Required Steps

1. Read `START_HERE.md`, `CURRENT_STATE.md`, `PROJECT_MEMORY.md`, and `AI_DEVELOPMENT_CHARTER.md`.
2. Inspect actual files under:
   - `apps/web/`
   - `03_Knowledge/Website/`
   - `01_Platform/Design_System/`
   - `02_Companies/Koinonia/`
3. Determine whether a real public website implementation exists in the repository.
4. If it exists, audit it.
5. If it does not exist, create the minimal canonical website structure before writing page code.
6. Begin with the Koinonia Home page or Services & Pricing page only after confirming the canonical implementation path.

## Do Not Do

- Do not mark Services & Pricing implementation complete from conversation history alone.
- Do not create duplicate page/component systems.
- Do not treat standalone prototype HTML as the production source.
- Do not produce a release unless actual repository files were changed.

## Recommended Next Sprint

Repository Sprint 1 — Koinonia Website Canonical Implementation Setup

Deliverables:

- Public website folder or app route decision.
- Canonical component/page location.
- First real page implementation target.
- Updated OS files and versioned release.
