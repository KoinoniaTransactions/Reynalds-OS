import { buildReadOnlyCopilotAnswer } from "@reynalds-os/ai";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const body = await request.json();

  const answer = buildReadOnlyCopilotAnswer({
    objectIds: body.objectIds ?? [],
    workflowIds: body.workflowIds ?? [],
    timelineEventIds: body.timelineEventIds ?? [],
    userRole: body.userRole ?? "Owner",
    question: body.question ?? ""
  });

  return NextResponse.json(answer);
}
