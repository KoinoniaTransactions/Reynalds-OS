import { NextResponse } from "next/server";

export async function GET() {
  return NextResponse.json({
    events: [],
    note: "Timeline API scaffold. Connect to Prisma in implementation phase."
  });
}
