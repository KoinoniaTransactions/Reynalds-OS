import { getDashboardMetrics } from "@reynalds-os/core";

const nav = [
  "Dashboard",
  "CRM",
  "Transactions",
  "Contracts",
  "Showings",
  "Operations",
  "Finance",
  "Customer Success",
  "Knowledge",
  "Reports",
  "Administration",
  "Object Explorer",
  "Timeline",
  "Workflows",
  "Automations",
  "Intelligence"
];

export function DashboardShell() {
  const metrics = getDashboardMetrics();

  return (
    <main className="ros-app">
      <aside className="ros-sidebar">
        <div className="ros-brand">
          <div className="ros-mark">R</div>
          <div>
            <strong>ROS</strong>
            <span>Koinonia ERP · v8.0</span>
          </div>
        </div>

        <nav>
          {nav.map((item) => (
            <a key={item} href="#" className={item === "Dashboard" ? "active" : ""}>
              {item}
            </a>
          ))}
        </nav>
      </aside>

      <section className="ros-main">
        <header className="ros-topbar">
          <input placeholder="Search objects, transactions, SOPs, commands..." />
          <button>+ New</button>
          <button>AI Command</button>
        </header>

        <div className="ros-eyebrow">ROS-0065 · Production Scaffold</div>
        <h1>Reynalds OS Production Codebase</h1>
        <p className="ros-subtitle">
          This is the first production application scaffold for Koinonia ERP and the broader Reynalds OS platform.
        </p>

        <section className="ros-grid">
          {metrics.map((metric) => (
            <article className="ros-card" key={metric.label}>
              <span>{metric.label}</span>
              <strong>{metric.value}</strong>
              <p>{metric.note}</p>
            </article>
          ))}
        </section>
      </section>
    </main>
  );
}
