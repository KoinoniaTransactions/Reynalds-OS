# Reynalds OS

## Current Release

ROS v10.1.0 — Professional Software Project Consolidation

## What This Is

Reynalds OS is now organized as a production software project, not just a static dashboard prototype.

This repository includes:

- Next.js / TypeScript production app scaffold.
- Prisma / PostgreSQL schema.
- Shared Object Engine.
- Dashboard analytics.
- CRM MVP.
- Transactions MVP.
- Operations Queue MVP.
- Finance MVP.
- Knowledge MVP.
- Read-only Copilot MVP.
- Notifications MVP.
- Workflow Automation Engine MVP.
- Authoritative `BRAIN/` documentation.

## Important

The old standalone Dashboard/App Shell v7.2 is superseded by the production app inside:

```text
apps/web/
```

## Start Here

Read these first:

```text
BRAIN/README.md
BRAIN/HANDOFF.md
docs/GITHUB_SETUP.md
docs/APP_SHELL_VERSION_GUIDANCE.md
```

## Local Development

```bash
pnpm install
cp .env.example .env
docker compose up -d
pnpm --filter @reynalds-os/database db:generate
pnpm --filter @reynalds-os/database db:migrate
pnpm --filter @reynalds-os/database db:seed
pnpm dev
```

Then open:

```text
http://localhost:3000
```

## Key Routes

- `/`
- `/objects`
- `/crm`
- `/transactions`
- `/operations`
- `/finance`
- `/knowledge`
- `/copilot`
- `/notifications`
- `/workflows`

## Current Warning

This project was generated in a sandbox. It still needs local installation, compile validation, runtime testing, and deployment hardening before production use.
