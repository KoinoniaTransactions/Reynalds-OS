# Developer Handoff

## Project Status

Reynalds OS has moved from planning/prototype into production scaffold.

## Do Not Start From

Do not start from the old v7.2 standalone app shell as the main application.

That file is useful historically, but it is superseded by the v10.1 production project.

## Start From

Start from:

```text
Reynalds_OS/
```

Primary app:

```text
apps/web/
```

Primary database schema:

```text
packages/database/prisma/schema.prisma
```

Primary source-of-truth docs:

```text
BRAIN/
```

## First Local Commands

```bash
pnpm install
cp .env.example .env
docker compose up -d
pnpm --filter @reynalds-os/database db:generate
pnpm --filter @reynalds-os/database db:migrate
pnpm --filter @reynalds-os/database db:seed
pnpm dev
```

## First Routes To Check

- `/`
- `/objects`
- `/crm`
- `/transactions`
- `/operations`
- `/finance`
- `/knowledge`
- `/copilot`
- `/notifications`
- `/workflows`

## Most Important Warning

This repository has been generated in a sandbox. It must be installed, compiled, and run locally before it should be treated as production-ready.
